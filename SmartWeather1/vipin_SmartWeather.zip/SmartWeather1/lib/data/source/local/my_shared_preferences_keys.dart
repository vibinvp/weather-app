enum MySharedKeys {
  theme,
  language,
  firstTimeLocation,
  userWeatherList,
  currentWeatherLocation,
  userFavoriteWeatherList,
  tempUnit
}
