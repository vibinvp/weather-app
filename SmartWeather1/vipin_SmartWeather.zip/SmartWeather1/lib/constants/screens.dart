// screens pushNamed names

// ignore_for_file: constant_identifier_names

const HOME_SCREEN = 'HOME_SCREEN';
const PICK_LOCATION_SCREEN = 'PICK_LOCATION_SCREEN';
const MANAGE_LOCATIONS_SCREEN = 'MANAGE_LOCATIONS_SCREEN';
const SETTING_SCREEN = 'SETTING_SCREEN';
