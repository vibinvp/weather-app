package com.example.weather_app_algoriza_75

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
